import org.apache.commons.cli.*;

import java.io.IOException;

public class Snc {
    public static void main(String[] args) {
        CommandLineParser parser = new DefaultParser();

        Options options = new Options();
        options.addOption("l", true, "서버모드로 실행하면, 포트를 입력하시오");

        try {
            CommandLine cmd = parser.parse(options, args);

            if (cmd.hasOption("l")) {
                int port = Integer.parseInt(cmd.getOptionValue("l"));
                Server server = new Server();
                server.start(port);
            } else {
                String[] arguments = cmd.getArgs();
                if (arguments.length < 2) {
                    throw new ParseException("인자가 부족함");
                }
                String hostname = arguments[0];
                int port = Integer.parseInt(arguments[1]);
                Client client = new Client();
                client.start(hostname, port);
            }
        } catch (ParseException e) {
            System.err.println("에러: " + e.getMessage());
            HelpFormatter formatter = new HelpFormatter();
            formatter.printHelp("snc [options] [hostname] [port]", options);
        } catch (IOException e) {
            System.err.println("에러: " + e.getMessage());
        }
    }

}