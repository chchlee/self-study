import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

class Server {

    private ServerSocket serverSocket;
    private Socket clientSocket;
    private BufferedReader in;
    private BufferedWriter out;

    public void start(int port) throws IOException {
        System.out.println("서버 소켓 생성");
        serverSocket = new ServerSocket(port);
        System.out.println("클라이언트 포트 번호 연결 " + port);

        clientSocket = serverSocket.accept();
        System.out.println("클라이언트 연결: " + clientSocket.getRemoteSocketAddress());

        in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
        out = new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream()));

        Thread readThread = new Thread(() -> {
            try {
                String inputLine;
                while ((inputLine = in.readLine()) != null) {
                    System.out.println("클라이언트: " + inputLine);
                }
            } catch (IOException e) {
                System.err.println("클라이언트 연결로부터 에러: " + e.getMessage());
            }
        });

        readThread.start();

        Thread writeThread = new Thread(() -> {
            try {
                BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in));
                String inputLine;
                while ((inputLine = stdin.readLine()) != null) {
                    out.write(inputLine + "\n");
                    out.flush();
                }
            } catch (IOException e) {
                System.err.println("클라이언트 에러: " + e.getMessage());
            }
        });

        writeThread.start();

        try {
            readThread.join();
            writeThread.join();
        } catch (InterruptedException e) {
            System.err.println("Interrupted: " + e.getMessage());
        }

        in.close();
        out.close();
        clientSocket.close();
        serverSocket.close();

        System.out.println("연결종료");
    }
}