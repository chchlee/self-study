import java.io.*;
import java.net.Socket;

public class Client {

    private Socket socket;
    private BufferedReader in;
    private BufferedWriter out;

    public void start(String hostname, int port) throws IOException {
        System.out.println("클라이언트 소켓 생성");
        socket = new Socket(hostname, port);
        System.out.println("연결 " + socket.getRemoteSocketAddress());

        in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));

        Thread readThread = new Thread(() -> {
            try {
                String inputLine;
                while ((inputLine = in.readLine()) != null) {
                    System.out.println("서버: " + inputLine);
                }
            } catch (IOException e) {
                System.err.println("서버로부터에러: " + e.getMessage());
            }
        });

        readThread.start();

        Thread writeThread = new Thread(() -> {
            try {
                BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in));
                String inputLine;
                while ((inputLine = stdin.readLine()) != null) {
                    out.write(inputLine + "\n");
                    out.flush();
                }
            } catch (IOException e) {
                System.err.println("서버로부터 에러: " + e.getMessage());
            }
        });

        writeThread.start();

        try {
            readThread.join();
            writeThread.join();
        } catch (InterruptedException e) {
            System.err.println("Interrupted 발생: " + e.getMessage());
        }

        in.close();
        out.close();
        socket.close();

        System.out.println("연결종료");
    }
}
